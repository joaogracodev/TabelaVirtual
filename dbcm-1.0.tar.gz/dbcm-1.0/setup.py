from setuptools import setup

setup(
    name='DBcm',
    version='1.0',
    description='Database context manager',
    author='HF Python 2e',
    author_email='hfpy2e@gmail.com',
    url='headfirstlabs.com',
    py_modules=['DBcm'],
)